<?php
	include("../../php/koneksi.php");
	session_start();
	if ($_POST['gallery'] == "1") {
		header("location:gallery.php?gallery=1&deskripsi=gallery1#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "2") {
		header("location:gallery.php?gallery=2&deskripsi=gallery2#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "3") {
		header("location:gallery.php?gallery=3&deskripsi=gallery3#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "4") {
		header("location:gallery.php?gallery=4&deskripsi=gallery4#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "5") {
		header("location:gallery.php?gallery=5&deskripsi=gallery5#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "6") {
		header("location:gallery.php?gallery=6&deskripsi=gallery6#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "7") {
		header("location:gallery.php?gallery=7&deskripsi=gallery7#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "8") {
		header("location:gallery.php?gallery=8&deskripsi=gallery8#deskripsi-gallery");
	}
	elseif ($_POST['gallery'] == "9") {
		header("location:gallery.php?gallery=9&deskripsi=gallery9#deskripsi-gallery");
	}
?>