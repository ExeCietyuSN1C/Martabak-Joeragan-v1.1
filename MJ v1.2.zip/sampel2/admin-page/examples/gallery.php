<?php
    include("../../php/koneksi.php");
    session_start();
    if($_SESSION['status'] != "login"){
        $_SESSION['login'] = "Anda Harus Login Dahulu";
        header("location:../index.php");
    }

    $gallery = $_GET['gallery'];
    $gallery1 = $koneksi->query("SELECT *FROM gallery LIMIT 3");
    $gallery2 = $koneksi->query("SELECT *FROM gallery WHERE Id_Gallery >3 LIMIT 3");
    $gallery3 = $koneksi->query("SELECT *FROM gallery WHERE Id_Gallery >6 LIMIT 3");
    $deskripsi_gallery = $koneksi->query("SELECT *FROM gallery WHERE Id_Gallery='".$gallery."'");
    while ($row5 = $deskripsi_gallery->fetch_assoc()) {
        $id_gallery = $row5['Id_Gallery'];
        $judul_deskripsi = $row5['Judul_Deskripsi'];
        $deskripsi = $row5['Deskripsi'];
        $category = $row5['Category'];
        $rasa1 = $row5['Rasa1'];
        $rasa2 = $row5['Rasa2'];
        $rasa3 = $row5['Rasa3'];
        $rasa4 = $row5['Rasa4'];
        $rasa5 = $row5['Rasa5'];
        $rasa6 = $row5['Rasa6'];
        $rasa7 = $row5['Rasa7'];
        $rasa8 = $row5['Rasa8'];
    }
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png" />
    <link rel="icon" type="image/png" href="../assets/img/favicon.png" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>Admin Gallery</title>
    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="../assets/css/material-dashboard.css?v=1.2.0" rel="stylesheet" />
    <link href="../assets/css/demo.css" rel="stylesheet" />
    <link href="../assets/css/font-awesome.css" rel="stylesheet" />
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300|Material+Icons' rel='stylesheet' type='text/css'>
</head>

<body>
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-image="../assets/img/sidebar-1.jpg">
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    Admin<br>
					Martabak Joeragan
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li>
                        <a href="dashboard.php">
                            <i class="material-icons">dashboard</i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li>
                        <a href="./user.php">
                            <i class="material-icons">person</i>
                            <p>User Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="./table.php">
                            <i class="material-icons">content_paste</i>
                            <p>Table List</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="./gallery.php">
                            <i class="material-icons">library_books</i>
                            <p>Gallery</p>
                        </a>
                    </li>
					<li>
                        <a href="./maps.php">
                            <i class="material-icons">location_on</i>
                            <p>Maps</p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"> Gallery </a>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="dashboard.php">
                                    <i class="material-icons">dashboard</i>
                                    <p class="hidden-lg hidden-md">Dashboard</p>
                                </a>
                            </li>
                            <li>
                                <a href="user.php">
                                    <i class="material-icons">person</i>
                                    <p class="hidden-lg hidden-md">Profile</p>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-plain">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title">Gallery</h4>
                                    <p class="category">Gallery dari Website Martabak Joeragan</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php
                                if ($_SESSION['pesan-gallery'] != "") {
                                    echo '
                                        <div class="alert alert-info" role="alert" align="center">
                                          <strong>'.$_SESSION["pesan-gallery"].'</strong>
                                        </div>
                                    ';
                                    $_SESSION["pesan-gallery"] = "";
                                }
                            ?>
                        </div>
                    </div>
                    <div class="row">
                        <?php
                            while ($row = $gallery1->fetch_assoc()) {
                                echo '
                                    <div class="col-md-4">
                                        <div class="card gallery">
                                            <h3 class="title">Gallery '.$gallery.'</h3><br>
                                            <img src='.$row["Foto"].' class="img-responsive" alt="Gallery 1"/><br><br>
                                            <form action="upload-gallery.php" method="post" enctype="multipart/form-data">Select image to upload:
                                                <input type="file" id="fileToUpload'.$row["Id_Gallery"].'" name="gallery1" style="display:none" onchange=document.getElementById("filename'.$row["Id_Gallery"].'").value=this.value>
                                                <input id="filename'.$row["Id_Gallery"].'" disabled="">
                                                <div class="deskripsi">
                                                    <a href="#deskripsi-gallery"><i class="fa fa-plus-square" aria-hidden="true"></i> Deskripsi</a>
                                                </div>
                                                <input type="button" value="Pilih Gambar / File" onclick=document.getElementById("fileToUpload'.$row["Id_Gallery"].'").click() class="btn btn-primary">
                                                <button type="submit" class="btn btn-primary ganti" name="submit" value="'.$row["Id_Gallery"].'">GANTI</button>
                                            </form>
                                        </div>
                                    </div>
                                ';
                            }
                        ?>
                    </div>
                    <div class="row">
                        <?php
                            while ($row2 = $gallery2->fetch_assoc()) {
                                echo '
                                    <div class="col-md-4">
                                        <div class="card gallery">
                                            <h3 class="title">Gallery '.$row2["Id_Gallery"].'</h3><br>
                                            <img src='.$row2["Foto"].' class="img-responsive" alt="Gallery 1"/><br><br>
                                            <form action="upload-gallery.php" method="post" enctype="multipart/form-data">Select image to upload:
                                                <input type="file" id="fileToUpload'.$row2["Id_Gallery"].'" name="gallery1" style="display:none" onchange=document.getElementById("filename'.$row2["Id_Gallery"].'").value=this.value>
                                                <input id="filename'.$row2["Id_Gallery"].'" disabled="">
                                                <div class="deskripsi">
                                                    <a href="#deskripsi-gallery"><i class="fa fa-plus-square" aria-hidden="true"></i> Deskripsi</a>
                                                </div>
                                                <input type="button" value="Pilih Gambar / File" onclick=document.getElementById("fileToUpload'.$row2["Id_Gallery"].'").click() class="btn btn-primary">
                                                <button type="submit" class="btn btn-primary ganti" name="submit" value="'.$row2["Id_Gallery"].'">GANTI</button>
                                            </form>
                                        </div>
                                    </div>
                                ';
                            }
                        ?>
                    <div class="row">
                        <?php
                            while ($row3 = $gallery3->fetch_assoc()) {
                                echo '
                                    <div class="col-md-4">
                                        <div class="card gallery">
                                            <h3 class="title">Gallery '.$row3["Id_Gallery"].'</h3><br>
                                            <img src='.$row3["Foto"].' class="img-responsive" alt="Gallery 1"/><br><br>
                                            <form action="upload-gallery.php" method="post" enctype="multipart/form-data">Select image to upload:
                                                <input type="file" id="fileToUpload'.$row3["Id_Gallery"].'" name="gallery1" style="display:none" onchange=document.getElementById("filename'.$row3["Id_Gallery"].'").value=this.value>
                                                <input id="filename'.$row3["Id_Gallery"].'" disabled="">
                                                <div class="deskripsi">
                                                    <a href="#deskripsi-gallery"><i class="fa fa-plus-square" aria-hidden="true"></i> Deskripsi</a>
                                                </div>
                                                <input type="button" value="Pilih Gambar / File" onclick=document.getElementById("fileToUpload'.$row3["Id_Gallery"].'").click() class="btn btn-primary">
                                                <button type="submit" class="btn btn-primary ganti" name="submit" value="'.$row3["Id_Gallery"].'">GANTI</button>
                                            </form>
                                        </div>
                                    </div>
                                ';
                            }
                        ?>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card card-plain" id="deskripsi-gallery">
                                <div class="card-header" data-background-color="red">
                                    <h4 class="title">Deskripsi Gallery</h4>
                                    <p class="category">Deskripsi Gallery dari Website Martabak Joeragan</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card card-deskripsi">
                                <div class="row">
                                    <form action="gallery-deskripsi.php" method="POST">
                                        <h4 class="title">Pilih Gallery</h4>
                                        <p class="category">Pilih Gallery Untuk Ditampilkan : </p>
                                        <div class="col-md-8">
                                            <select class="form-control" id="gallery-deskripsi" name="gallery">
                                                <option value="1">Gallery 1</option>
                                                <option value="2">Gallery 2</option>
                                                <option value="3">Gallery 3</option>
                                                <option value="4">Gallery 4</option>
                                                <option value="5">Gallery 5</option>
                                                <option value="6">Gallery 6</option>
                                                <option value="7">Gallery 7</option>
                                                <option value="8">Gallery 8</option>
                                                <option value="9">Gallery 9</option>
                                            </select>
                                        </div>
                                        <div class="col-md-4" align="center">
                                            <button type="submit" class="btn btn-primary" name="submit">Open</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card" id="Deskripsi-Gallery1">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title">Deskripsi Gallery <?php echo $id_gallery; ?></h4>
                                    <p class="category">Isi Data Deskripsi Gallery <?php echo $id_gallery; ?></p>
                                </div>
                                <div class="card-content">
                                    <form action="gallery.php?gallery=<?php echo $id_gallery; ?>#Deskripsi-Gallery1" method="POST">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Judul Deskripsi</label>
                                                    <input name="judul-deskripsi" type="text" class="form-control" value="<?php echo $judul_deskripsi; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label"> Deskripsi</label>
                                                    <input name="deskripsi" type="text" class="form-control" value="<?php echo $deskripsi; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Category</label>
                                                    <input name="category" type="text" class="form-control" value="<?php echo $category; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 1</label>
                                                    <input name="rasa1" type="text" class="form-control" value="<?php echo $rasa1; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 2 (*Optional)</label>
                                                    <input name="alamat" type="text" class="form-control" value="<?php echo $rasa2; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 3 (*Optional)</label>
                                                    <input name="rasa3" type="text" class="form-control" value="<?php echo $rasa3; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 4 (*Optional)</label>
                                                    <input name="rasa4" type="text" class="form-control" value="<?php echo $rasa4; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 5 (*Optional)</label>
                                                    <input name="rasa5" type="text" class="form-control" value="<?php echo $rasa5; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 6 (*Optional)</label>
                                                    <input name="rasa6" type="text" class="form-control" value="<?php echo $rasa6; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 7 (*Optional)</label>
                                                    <input name="rasa7" type="text" class="form-control" value="<?php echo $rasa7; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 8 (*Optional)</label>
                                                    <input name="rasa8" type="text" class="form-control" value="<?php echo $rasa8; ?>" disabled />
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary pull-right" name="submit" value="1">Refresh</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card" id="deskripsi-galerry">
                                <div class="card-header" data-background-color="purple">
                                    <h4 class="title">Deskripsi Gallery <?php echo $id_gallery; ?></h4>
                                    <p class="category">Edit Deskripsi Gallery <?php echo $id_gallery; ?></p>
                                </div>
                                <div class="card-content">
                                    <form action="update_deskripsi.php" method="POST">
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Judul Deskripsi</label>
                                                    <input name="judul-deskripsi" type="text" class="form-control" required />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label"> Deskripsi</label>
                                                    <input name="deskripsi" type="text" class="form-control" required />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Category</label>
                                                    <input name="category" type="text" class="form-control" required />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 1</label>
                                                    <input name="rasa1" type="text" class="form-control" required />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 2 (*Optional)</label>
                                                    <input name="rasa2" type="text" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 3 (*Optional)</label>
                                                    <input name="rasa3" type="text" class="form-control" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 4 (*Optional)</label>
                                                    <input name="rasa4" type="text" class="form-control" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 5 (*Optional)</label>
                                                    <input name="rasa5" type="text" class="form-control" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 6 (*Optional)</label>
                                                    <input name="rasa6" type="text" class="form-control" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 7 (*Optional)</label>
                                                    <input name="rasa7" type="text" class="form-control" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Rasa 8 (*Optional)</label>
                                                    <input name="rasa8" type="text" class="form-control" />
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary pull-right" name="submit" value="<?php echo $id_gallery; ?>">Update Deskripsi</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container-fluid">
                    <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="../../index.php">Martabak Joeragan Coveration</a>
                    </p>
                </div>
            </footer>
        </div>
    </div>
</body>
<script src="../assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="../assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/js/material.min.js" type="text/javascript"></script>
<script src="../assets/js/chartist.min.js"></script>
<script src="../assets/js/arrive.min.js"></script>
<script src="../assets/js/perfect-scrollbar.jquery.min.js"></script>
<script src="../assets/js/bootstrap-notify.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
<script src="../assets/js/material-dashboard.js?v=1.2.0"></script>
<script src="../assets/js/demo.js"></script>

</html>